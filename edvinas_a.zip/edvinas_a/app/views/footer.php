<footer class="footer">
        <div class="container flex-container">
            <div class="logo flex-container">
                <a href="#"><img src="../app/images/page_logo.png" alt="Juliana photography"></a>
                <p class="copyright">&copy; <?php echo date('Y'); ?></p>
            </div>
            <nav class="nav footer-nav">
                <ul class="flex-container">
                    <li><a href="mailto:juliana10@gmail.com">juliana10@gmail.com</a></li>
                    <li><a href="tel:868686868">+37068686868</a></li>
                </ul>
            </nav>
        </div>
</footer>