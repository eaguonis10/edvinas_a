<header class="site-header">
        <div class="container flex-container">
            <div class="logo">
                <a href="#"><img src="../app/images/page_logo.png" alt="Juliana photography"></a>
            </div>
            <nav class="main-nav flex-container">
                <ul class="flex-container">
                    <li><a href="#">Paslaugos</a></li>
                    <li><a href="#">Galerija</a></li>
                    <li><a href="#">Kainos</a></li>
                    <li><a href="#">Apie</a></li>
                    <li><a href="#">Kontaktai</a></li>
                </ul>
            </nav>
            <nav class="mobile-nav">
                <ul id="mMenu" class="flex-container">
                    <li><a href="#">Paslaugos</a></li>
                    <li><a href="#">Galerija</a></li>
                    <li><a href="#">Kainos</a></li>
                    <li><a href="#">Apie</a></li>
                    <li><a href="#">Kontaktai</a></li>
                </ul>
                <a href="javascript:void(0);" class="icon" onclick="myFunction()">
                    <i class="fa fa-bars"></i>
                </a>
            </nav>
        </div>
</header>