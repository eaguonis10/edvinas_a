<main>

    <!-- HERO -->

    <section class="hero">
        <div id="arrow-left" class="arrow"><i class="far fa-arrow-alt-circle-left"></i></div>
        <div id="slider">
            <div class="slide slide1">
                <div class="slide-content">
                    <div class="container flex-container">
                        <div class="section-text">
                            <h1>Juliana photography</h1>
                            <h2>Kurkime šventę kartu</h2>
                        </div>
                        <div class="section-icons flex-container">
                            <img src="../app/images/camera.png" alt="kamera">
                            <img src="../app/images/inbox.png" alt="pašto dėžutė">
                            <img src="../app/images/printer.png" alt="spausdintuvas">
                            <img src="../app/images/heart.png" alt="širdis" class="blink_me">
                            <img src="../app/images/envelope.png" alt="vokas">
                            <img src="../app/images/location.png" alt="vietovė">
                            <img src="../app/images/calendar.png" alt="kalendorius">
                            <img src="../app/images/sun.png" alt="saulė">
                        </div>
                    </div>
                </div>
            </div>
            <div class="slide slide2">
                <div class="slide-content">
                    <div class="container flex-container">
                        <div class="section-text">
                            <h1>Juliana photography</h1>
                            <h2>Kurkime Šventę Kartu</h2>
                        </div>
                        <div class="section-icons flex-container">
                            <img src="../app/images/camera.png" alt="kamera">
                            <img src="../app/images/inbox.png" alt="pašto dėžutė">
                            <img src="../app/images/printer.png" alt="spausdintuvas">
                            <img src="../app/images/heart.png" alt="širdis" class="blink_me">
                            <img src="../app/images/envelope.png" alt="vokas">
                            <img src="../app/images/location.png" alt="vietovė">
                            <img src="../app/images/calendar.png" alt="kalendorius">
                            <img src="../app/images/sun.png" alt="saulė">
                        </div>
                    </div>
                </div>
            </div>
            <div class="slide slide3">
                <div class="slide-content">
                    <div class="container flex-container">
                        <div class="section-text">
                            <h1>Juliana photography</h1>
                            <h2>Kurkime Šventę Kartu</h2>
                        </div>
                        <div class="section-icons flex-container">
                            <img src="../app/images/camera.png" alt="kamera">
                            <img src="../app/images/inbox.png" alt="pašto dėžutė">
                            <img src="../app/images/printer.png" alt="spausdintuvas">
                            <img src="../app/images/heart.png" alt="širdis" class="blink_me">
                            <img src="../app/images/envelope.png" alt="vokas">
                            <img src="../app/images/location.png" alt="vietovė">
                            <img src="../app/images/calendar.png" alt="kalendorius">
                            <img src="../app/images/sun.png" alt="saulė">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="arrow-right" class="arrow"><i class="far fa-arrow-alt-circle-right"></i></div>
    </section>

    <!-- SERVICES -->

    <section class="services">
        <div class="container">
            <div class="section-text">
                <h2>Fotosesijos</h2>
            </div>
            <div class="section-services flex-container">
                <div class="service">
                    <i class="far fa-smile-wink"></i>
                    <h3>Šeimos</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla, dolorum.</p>
                </div>
                <div class="service">
                    <i class="fas fa-hockey-puck"></i>
                    <h3>Vestuvės</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla, dolorum.</p>
                </div>
                <div class="service">
                    <i class="fas fa-baby-carriage"></i>
                    <h3>Krikštynos</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla, dolorum.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- CONTACTME -->

    <section class="contactme">
        <div class="cover-photo">
            <div class="container">
                <div class="section-text">
                    <h2>Norite sužinoti daugiau?</h2>
                </div>
                <div class="section-buttons flex-container">
                    <a href="tel:868686868">Skambinti</a>
                    <a href="https://facebook.com/Juliana" target="_blank">Sekti</a>
                </div>
            </div>
        </div>
    </section>

    <!-- GALLERY -->

    <section class="gallery">
        <div class="container">
            <div class="section-text">
                <h2>Galerija</h2>
            </div>
            <div class="section-button">
                <a href="#">Visa galerija</a>
            </div>
            <div class="section-gallery">
                <img data-enlargeable width="100" style="cursor: pointer" src="../app/images/1.jpg" alt="vestuvės">
                <img data-enlargeable width="100" style="cursor: pointer" src="../app/images/2.jpg" alt="vaikas">
                <img data-enlargeable width="100" style="cursor: pointer" src="../app/images/3.jpg" alt="žiedai">
                <img data-enlargeable width="100" style="cursor: pointer" src="../app/images/4.jpg" alt="berniukas">
                <img data-enlargeable width="100" style="cursor: pointer" src="../app/images/5.jpg" alt="rankos">
                <img data-enlargeable width="100" style="cursor: pointer" src="../app/images/7.jpg" alt="balionai">
                <img data-enlargeable width="100" style="cursor: pointer" src="../app/images/8.jpg" alt="žmonės">
                <img data-enlargeable width="100" style="cursor: pointer" src="../app/images/9.jpg" alt="kojos">
            </div>
            <div class="section-load">
                <a href="#contacts" class="smooth-goto">Kontaktai</a>
                <a href="#contacts" class="smooth-goto"><i class="fas fa-chevron-down"></i></a>
            </div>
        </div>
    </section>

    <!-- TEXT1 -->

    <section class="text1">
        <div class="cover-photo">
            <div class="container">
                <div class="section-text">
                    <h2>Kainoraštis</h2>
                    <h3>Visuomet geriausi pasiūlymai</h3>
                </div>
            </div>
        </div>
    </section>

    <!-- TABLE -->

    <section class="table">
        <div class="container">
            <div class="section-text">
                <h2>Kainos</h2>
            </div>
            <div class="section-tables flex-container">
                <div class="price">
                    <h3>Šeimos</h3>
                    <h4>250€/diena</h4>
                    <p><b>120€</b>/3 val.</p>
                    <p><b>90€</b>/2 val.</p>
                    <p><b>50€</b>/1 val.</p>
                    <a href="tel:868686868">Skambinti</a>
                </div>
                <div class="price">
                    <h3>Vestuvės</h3>
                    <h4>250€/diena</h4>
                    <p><b>120€</b>/3 val.</p>
                    <p><b>90€</b>/2 val.</p>
                    <p><b>50€</b>/1 val.</p>
                    <a href="tel:868686868">Skambinti</a>
                </div>
                <div class="price">
                    <h3>Krikštynos</h3>
                    <h4>250€/diena</h4>
                    <p><b>120€</b>/3 val.</p>
                    <p><b>90€</b>/2 val.</p>
                    <p><b>50€</b>/1 val.</p>
                    <a href="tel:868686868">Skambinti</a>
                </div>
            </div>
            <div class="section-comment">
                <h3><span>Klientai apie mane</span></h3>
                <div class="section-text flex-container">
                    <i class="fas fa-quote-left"></i>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dicta perferendis vel debitis explicabo
                        corrupti, fugiat voluptate quas voluptatem consequatur possimus porro, tempora dolor sint.
                        Magnam officiis et itaque ea omnis?</p>
                    <i class="fas fa-quote-right"></i>
                </div>
                <h4>#Tomas Stonkus</h4>
            </div>
        </div>
    </section>

    <!-- TEXT2 -->

    <section class="text2">
        <div class="cover-photo">
            <div class="container">
                <div class="section-text">
                    <h2>Aš su Jumis</h2>
                    <h3>Visada profesionali ir nuolat tobulėjanti</h3>
                </div>
            </div>
        </div>
    </section>

    <!-- ABOUT -->

    <section class="about">
        <div class="container">
            <div class="section-text">
                <h2>Apie Mane</h2>
            </div>
            <div class="section-people">
                <img src="../app/images/11.jpg" alt="fotografas">
                <h4>Juliana Aguonė</h4>
                <h5>Fotografas</h5>
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dolores vitae velit molestiae dolor
                    similique suscipit repudiandae, corporis, sed saepe expedita consequatur enim debitis repellendus
                    nihil! Debitis temporibus mollitia inventore quod.</p>
            </div>
            <div class="section-line">
                <h4><span>Mano patirtis</span></h4>
            </div>
            <div class="circles flex-container">
                <div class="progress">
                    <div class="barOverflow">
                        <div class="bar"></div>
                    </div>
                    <span>250</span>
                    <p>Klientų</p>
                </div>
                <div class="progress">
                    <div class="barOverflow">
                        <div class="bar"></div>
                    </div>
                    <span>500</span> val.
                    <p>Patirties</p>
                </div>
                <div class="progress">
                    <div class="barOverflow">
                        <div class="bar"></div>
                    </div>
                    <span>10</span> m.
                    <p>Kartu</p>
                </div>
                <div class="progress">
                    <div class="barOverflow">
                        <div class="bar"></div>
                    </div>
                    <span>100</span> %
                    <p>Šypsenų</p>
                </div>
            </div>
        </div>
    </section>

    <!-- TEXT3 -->

    <section class="text3">
        <div class="cover-photo">
            <div class="container">
                <div class="section-text">
                    <h2>Atrodai nuostabiai</h2>
                    <h3>Ir tai puiku!</h3>
                </div>
            </div>
        </div>
    </section>

    <!-- CONTACT-FORM -->

    <section class="contact-form">
        <div class="container">
            <h3 id="contacts">Susisiekite</h3>
            <div class="flex-container">
                <div class="section-first">
                    <div class="section-text">
                        <h4>Paštas</h4>
                    </div>
                    <div class="section-form">
                        <form id="contact" action="index.php" method="post">
                            <div class="inputs">
                                <label><input name="vardas" type="text" placeholder="Vardas" required
                                        autofocus /></label>
                                <label><input name="email" type="email" placeholder="El. paštas" required /></label>
                            </div>
                            <label><textarea name="message" placeholder="Žinutė" required></textarea></label><br>
                            <input name="submit" type="submit" id="contact-submit" value="Siųsti" />
                        </form>
                    </div>
                </div>
                <div class="section-second">
                    <div class="section-text">
                        <h4>Daugiau</h4>
                        <a href="tel:868686868">+37068686868</a><br>
                        <a href="mailto:juliana10@gmail.com">juliana10@gmail.com</a><br><br>
                        <p><span>Juliana</span> Aguonė</p>
                        <p><span>Kaunas</span> Lietuva</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CONNECT -->

    <section class="connect">
        <div class="cover-photo">
            <div class="container">
                <div class="section-text">
                    <h2>Bendraukime</h2>
                    <h3>Sekite Mane Socialiniuose Tinkluose </h3>
                </div>
                <div class="section-icons">
                    <ul class="flex-container">
                        <li><a href="https://facebook.com/juliana" target="_blank"><i class="fab fa-facebook"></i></a>
                        </li>
                        <li><a href="https://instagram.com/juliana" target="_blank"><i class="fab fa-instagram"></i></a>
                        </li>
                        <li><a href="https://pinterest.com/juliana" target="_blank"><i class="fab fa-pinterest"></i></a>
                        </li>
                        <li><a href="https://twitter.com/juliana" target="_blank"><i class="fab fa-twitter"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
</main>